// Main scripts file
import './js/index';

// Main styles file
import './scss/main.scss';

// Images
import './media/sylius-logo.png';
import './media/sylius-plus.png';
